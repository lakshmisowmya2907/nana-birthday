# Nana Birthday Surprise

Open `index.html` in a browser to preview the website.

The first version intentionally contains no personal photos.
To personalize it later, photos and music can be added locally.

Main details:
- Birthday: 12 September 2026
- Friend addressed as: Nana
- Special signature: Chinnu ❤️ Chitti
- Style: romantic + emotional + birthday + togetherness
- Mobile-friendly
